package service;

import model.Pais;

import java.util.ArrayList;

import dao.PaisDAO;

public class PaisService {
	
	private PaisDAO dao;

	public PaisService() {
		dao = new PaisDAO();
	}
	
	public int criar(Pais pais) {
		return dao.criar(pais);
	}

	public void atualizar(Pais pais) {
		dao.atualizar(pais);
	}

	public void excluir(Pais pais) {
		dao.excluir(pais);
	}
	
	public void excluir(int id) {
		dao.excluir(new Pais(id));
	}
	
	public Pais carregar(Pais pais) {
		return dao.carregar(pais);
	}

	public Pais carregar(int id) {
		return dao.carregar(new Pais(id));
	}
	
	public ArrayList<Pais> listarPaises() {
		return dao.listarPaises();
	}

	public ArrayList<Pais> listarPaises(String chave) {
		return dao.listarPaises(chave);
	}

}
